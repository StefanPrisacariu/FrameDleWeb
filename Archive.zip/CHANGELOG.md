## 1.2.6

-   Stefan: COmplete Refactor: React -> Next.js

## 1.2.5

-   Stefan: Ui Improvement, Share functionality, Temple + Yareli Prime

## 1.2.4

-   Stefan: Time Management + Refactoring Main Game

## 1.2.3

-   Cristi: Testing

## 1.2.3

-   Stefan Prisacariu: Lavos Prime Added

## 1.0.0

-   Stefan Prisacariu: Main Branch
