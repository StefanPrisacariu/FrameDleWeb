export interface OverwatchEntry {
    id: number;
    name: string;
    link: string;
}
