Silence is a bliss
