export type Styles = {
  'fd_logo_0': string;
  'fd_logo_1': string;
};

export type ClassNames = keyof Styles;

declare const styles: Styles;

export default styles;
