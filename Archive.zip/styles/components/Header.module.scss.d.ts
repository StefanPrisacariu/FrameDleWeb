export type Styles = {
  'fd_header_0': string;
};

export type ClassNames = keyof Styles;

declare const styles: Styles;

export default styles;
