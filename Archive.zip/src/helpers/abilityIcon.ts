export const abilityIcon = (e: string) => {
    return `https://wiki.warframe.com/images/thumb/${e}/512px-${e}`;
};
